--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Quiz_PBO";
--
-- Name: Quiz_PBO; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Quiz_PBO" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Indonesian_Indonesia.1252';


ALTER DATABASE "Quiz_PBO" OWNER TO postgres;

\unrestrict (null)
\connect "Quiz_PBO"
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: operasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.operasi (
    id bigint NOT NULL,
    bilangan1 double precision NOT NULL,
    operator character varying(1) NOT NULL,
    bilangan2 double precision NOT NULL
);


ALTER TABLE public.operasi OWNER TO postgres;

--
-- Name: operasi_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.operasi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.operasi_id_seq OWNER TO postgres;

--
-- Name: operasi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.operasi_id_seq OWNED BY public.operasi.id;


--
-- Name: operasi id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operasi ALTER COLUMN id SET DEFAULT nextval('public.operasi_id_seq'::regclass);


--
-- Data for Name: operasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.operasi (id, bilangan1, operator, bilangan2) FROM stdin;
\.
COPY public.operasi (id, bilangan1, operator, bilangan2) FROM '$$PATH$$/5007.dat';

--
-- Name: operasi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.operasi_id_seq', 5, true);


--
-- Name: operasi operasi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operasi
    ADD CONSTRAINT operasi_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

